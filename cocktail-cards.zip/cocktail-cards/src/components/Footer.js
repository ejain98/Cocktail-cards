function Footer() {
  return (
    <footer className="footer">
      <p>Copyright &copy; Harveer Singh and Ekta Jain CSIS 3380_003 (2022)</p>
    </footer>
  );
}

export default Footer;
